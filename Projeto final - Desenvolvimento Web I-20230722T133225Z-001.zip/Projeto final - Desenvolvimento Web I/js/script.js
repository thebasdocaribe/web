let editingCard;
let contagem = 1;

async function getJogo(){
    try{
        var jogoBusca = await fetch("https://free-to-play-games-database.p.rapidapi.com/api/games?rapidapi-key=d3f5df13b2msh578a70965cca9a4p1bc6b6jsna790dcce35ea")
        jogoJson = await jogoBusca.json()
        if(jogoJson.error){
            throw Error("Erro no FETCH da API");
        }
        return jogoJson;
    }catch(error){
        console.log(error);
    }
}

function createJogoCard(jogo, descricao) {
    const jogoCard = {
        title: jogo.title,
        avaliacao: descricao,
        img: jogo.thumbnail
    };

    const gostei = document.getElementById('OpcaoLike').checked;
    const Naogostei = document.getElementById('OpcaoDeslike').checked;
        if(gostei){
            gostounaogostou = '/img/like.png';
        }
        else if (Naogostei){
            gostounaogostou = '/img/deslike.png';

        }

    const card = document.createElement('div');
    card.className = 'card col-lg-3 col-md-4 col-sm-12';
    card.style.transition = 'transform 0.3s ease';
    const img = document.createElement('img');
    img.className = 'card-img-top';
    img.src = jogoCard.img;
    img.alt = jogoCard.title;
    img.style = 'max-height: 200px'

    const cardBody = document.createElement('div');
    cardBody.className = 'card-body';

    const title = document.createElement('h5');
    title.className = 'card-title';
    title.textContent = jogoCard.title;

    const avaliacao = document.createElement('p');
    avaliacao.className = 'card-text';
    avaliacao.textContent = jogoCard.avaliacao;
    card.avaliacaoElement=avaliacao;

    const likeDeslike = document.createElement('img');
    likeDeslike.className = 'like-deslike';
    likeDeslike.src = gostounaogostou;
    likeDeslike.alt = 'like ou deslike';


    const editButton = document.createElement('button');
    editButton.className = 'edit-button btn btn-warning';
    editButton.href = '#';
    editButton.textContent = 'Editar';

    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-button btn btn-danger';
    deleteButton.href = '#';
    deleteButton.textContent = 'Remover';

    cardBody.appendChild(title);
    cardBody.appendChild(avaliacao);
    cardBody.appendChild(likeDeslike);
    cardBody.appendChild(editButton);
    cardBody.appendChild(deleteButton);
    card.appendChild(img);
    card.appendChild(cardBody);

    card.addEventListener('mouseenter', function () {
        card.classList.add('highlighted');
    });

    card.addEventListener('mouseleave', function () {
        card.classList.remove('highlighted');
    });

    card.addEventListener('click',function(event){
        if (event.target.className === 'delete-button btn btn-danger') {
            const card = event.target.closest('.card');
            if (confirm('Você tem certeza de que deseja excluir esta avaliação?')) {
                removeJogoCard(card);
            }
        } else if (event.target.className === 'edit-button btn btn-warning') {
            openModal(jogoCard,card);
        }
    });
    return card;
}

openModal = (jogoCard,card) => {
    const editModal = new bootstrap.Modal(document.getElementById('editJogoModal'));
    const avaliacaoTextArea = document.getElementById('jogo-avaliacao');
    avaliacaoTextArea.value = jogoCard.avaliacao
    editingCard = {card: card};
    editModal.show();
};

async function addJogoCard() {
    const jogo = await getJogo();
    const avaliacao = document.getElementById('TextoAvaliacao').value;
    const container = document.getElementById('cardContainer');


    if (jogo.length >= contagem) {
        const element = jogo[contagem - 1];
        const card = createJogoCard(element, avaliacao);
        container.appendChild(card);
        
    
    }
    contagem++;
}

function removeJogoCard(card) {
    const container = document.getElementById('cardContainer');
    container.removeChild(card);
}

function updateModal(jogo) {
    const modalImage = document.getElementById('ImageModal');
    const modalAvaliacao = document.getElementById('TextoAvaliacao');

    modalImage.src = jogo.thumbnail;
    modalImage.alt = jogo.title;
    modalAvaliacao.value = '';
}

document.getElementById('botaoCritica').addEventListener('click', async function(event) {
    event.preventDefault();
    const jogo = await getJogo();

    if (jogo.length >= contagem) {
        updateModal(jogo[contagem - 1]);
        const addJogoModal = new bootstrap.Modal(document.getElementById('CriticaModal'));
        addJogoModal.show();

        const closeButton = document.querySelector('#CriticaModal .btn-close');
        closeButton.addEventListener('click', function() {
            addJogoModal.hide();
            const backdrop = document.querySelector('.modal-backdrop');
            backdrop.parentNode.removeChild(backdrop);
        });

    } else {
        console.log('Nenhum jogo encontrado.');
    }
});

document.getElementById('Fazer-Critica').addEventListener('submit', function (event) {
    event.preventDefault();
    addJogoCard();
    const addJogoModal = bootstrap.Modal.getInstance(document.getElementById('CriticaModal'));
    addJogoModal.hide();
    const backdrop = document.querySelector('.modal-backdrop');
    backdrop.parentNode.removeChild(backdrop);
});

document.getElementById('submitJogoEdit').addEventListener('click', function(event) {
    event.preventDefault();
    const newAvaliacao = document.getElementById('jogo-avaliacao').value;
    const editModal = bootstrap.Modal.getInstance(document.getElementById('editJogoModal'));

    if (editingCard) {
        editingCard.card.avaliacaoElement.textContent = newAvaliacao;
        editingCard.card.avaliacao = newAvaliacao;
    }
    editModal.hide();
});

async function getJogoById(idJogo){
    try{
        var buscarJogo = await fetch("https://free-to-play-games-database.p.rapidapi.com/api/game?id="+idJogo+"&rapidapi-key=d3f5df13b2msh578a70965cca9a4p1bc6b6jsna790dcce35ea")
        buscarJogoJson = await buscarJogo.json()

        if(buscarJogoJson.error){
            throw Error("Erro no FETCH da API (buscar por ID)");
        }
        return buscarJogoJson;
    }catch(error){
        console.log(error);
    }
}

function updateModalBuscar(jogo) {
    const modalBuscaJogoImage = document.getElementById('busca-jogo-img');
    const modalBuscaJogoDescricao = document.getElementById('descricaoJogo');
    const modalBuscaJogoInput = document.getElementById('buscaIdJogo');

    modalBuscaJogoImage.src = jogo.thumbnail;
    modalBuscaJogoDescricao.alt = jogo.title;
    modalBuscaJogoDescricao.textContent = jogo.short_description;
    modalBuscaJogoInput.value = '';
}

document.getElementById('submitBuscaJogo').addEventListener('click', async function(event) {
    event.preventDefault();

    var jogoId = document.getElementById('buscaIdJogo').value;
    const jogo = await getJogoById(jogoId);

    if (jogo) {
        updateModalBuscar(jogo);
        const buscaJogoModal = new bootstrap.Modal(document.getElementById('buscaJogoModal'));
        buscaJogoModal.show();

        const closeButton = document.querySelector('#buscaJogoModal .btn-close');
        closeButton.addEventListener('click', function() {
            buscaJogoModal.hide();
            const backdrop = document.querySelector('.modal-backdrop');
            backdrop.parentNode.removeChild(backdrop);
        });

    } else {
        console.log('Nenhum jogo encontrado.');
    }
});